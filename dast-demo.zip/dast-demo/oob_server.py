"""
Minimal OOB (out-of-band) callback server.

The scanner registers a unique token before firing each SSRF/blind-injection
probe.  If the target application makes an outbound request to this server,
the token is captured and the finding is elevated to validation_level=2.
"""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

_callbacks: dict[str, float] = {}   # token -> received_timestamp
_lock = threading.Lock()


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path.lstrip("/")

        if path == "health":
            self._respond(200, {"status": "ok"})
            return

        if path.startswith("cb/"):
            token = path[3:]
            with _lock:
                _callbacks[token] = time.time()
            self._respond(200, {"received": token})
            print(f"[OOB] callback received for token={token}", flush=True)
            return

        if path.startswith("poll/"):
            token = path[5:]
            with _lock:
                hit = _callbacks.get(token)
            self._respond(200, {"token": token, "received": hit is not None, "ts": hit})
            return

        self._respond(404, {"error": "not found"})

    def _respond(self, code, body):
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):  # suppress default access log noise
        pass


if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", 8877), _Handler)
    print("[OOB] server listening on :8877", flush=True)
    server.serve_forever()
