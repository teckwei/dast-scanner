# DAST Scanner — Demo

A self-service Dynamic Application Security Testing (DAST) scanner built on an open-source Python stack. Designed to be **safe to run**, **trustworthy in output**, and **actionable** — not just a flood of findings.

---

## Quick Start (10 minutes)

### Prerequisites

| Tool | Version |
|------|---------|
| Docker + Docker Compose | 24+ |
| Python | 3.10+ |
| pip | 23+ |

### 1 — Clone and install

```bash
git clone <repo-url> dast-demo
cd dast-demo

pip install -r requirements.txt
# Optional: headless browser support
playwright install chromium
```

### 2 — Start the target (OWASP Juice Shop)

```bash
docker compose up -d juiceshop oob-server
# Wait ~30 s for Juice Shop to become ready
curl -s http://localhost:3000 | head -5
```

### 3 — Verify authorization

```bash
python -m dast.cli verify --target http://localhost:3000 --method manual
# Confirm you are authorized → proceeds
```

### 4 — Run the baseline scan

```bash
python -m dast.cli scan --config scan.yaml --out reports
```

Emits:
- `reports/scan-001.sarif` — machine-readable SARIF 2.1.0
- `reports/scan-001.html` — human-readable report (open in browser)
- `reports/audit-scan-001.jsonl` — complete audit log

```bash
open reports/scan-001.html    # macOS
xdg-open reports/scan-001.html  # Linux
```

### 5 — Run a second scan and diff

```bash
python -m dast.cli scan --config scan2.yaml --out reports
python -m dast.cli diff reports/scan-001.sarif reports/scan-002.sarif --out reports
open reports/diff.html
```

The diff shows:
- **Introduced** — new findings (regressions)
- **Resolved** — findings that disappeared (fixes confirmed)
- **Unchanged** — persistent findings

---

## Or use the demo scripts

```bash
chmod +x scripts/scan1.sh scripts/scan2.sh
./scripts/scan1.sh   # scan + report
./scripts/scan2.sh   # scan2 + diff
```

---

## CLI Reference

```
python -m dast.cli [COMMAND] [OPTIONS]

Commands:
  scan     Run a full scan
  verify   Check target authorization only
  diff     Compare two SARIF files
  abort    Abort a running scan (Ctrl-C also works)

scan options:
  --config PATH          Scan YAML config file  [required]
  --scan-id TEXT         Override auto-generated scan ID
  --out DIR              Output directory  [default: reports]
  --format TEXT          sarif,html  [default: sarif,html]
  --fail-on LEVEL        Exit 1 if findings at this level exist
                         choices: critical|high|medium|low|none
                         [default: high]
```

---

## Scan Config Reference (`scan.yaml`)

```yaml
scan_id: scan-001

target:
  url: https://staging.example.com
  authorization:
    method: manual            # manual | dns_txt | file_probe
    confirmed_by: "your-name"
  scope:
    include:
      - "https://staging.example.com/*"
    exclude:
      - "https://staging.example.com/logout"
      - "https://staging.example.com/api/payment/*"

crawl:
  max_pages: 100
  headless: false             # true = Playwright SPA rendering
  respect_robots_txt: true
  login_script:               # authenticated scan
    - {action: fill,      selector: "#email",    value: "user@example.com"}
    - {action: fill,      selector: "#password", value: "Password1"}
    - {action: click,     selector: "button[type=submit]"}
    - {action: wait_for,  selector: ".dashboard"}

rate_limits:
  max_qps: 5
  max_concurrency: 5

ci:
  fail_on: high
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  CLI (dast/cli.py)  ── Click commands                       │
└────────────────────────┬────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│  Engine (dast/engine.py)                                    │
│                                                             │
│  1. SafetyController   ← scope, rate, blocklist, audit      │
│  2. Fingerprinter      ← tech stack detection               │
│  3. StaticCrawler      ← HTML parser, link/form extraction  │
│  4. HeadlessCrawler    ← Playwright, XHR intercept (opt.)   │
│  5. Plugin Router      ← dispatches URLs to each plugin     │
│  6. Validator          ← canary tokens, OOB callbacks       │
└─────┬───────────────────────────────────────────────────────┘
      │ findings[]
┌─────▼───────────────────────────────────────────────────────┐
│  Reports                                                    │
│  ├── sarif.py   → SARIF 2.1.0 JSON                         │
│  ├── html.py    → HTML report (exec + dev + table views)    │
│  └── diff.py    → scan-to-scan diff (introduced/resolved)   │
└─────────────────────────────────────────────────────────────┘
```

### Plugins

| Plugin | Category | OWASP | Validation Level |
|--------|----------|-------|-----------------|
| `headers/` | Security Headers | A05:2021 | 1 — Signature |
| `sqli/` | SQL Injection | A03:2021 | 1 — Signature (error message) |
| `xss/` | Reflected XSS | A03:2021 | **2 — Exploited** (canary token reflected) |
| `ssrf/` | SSRF | A10:2021 | **2 — Exploited** (OOB callback received) |
| `sensitive_info/` | Info Exposure | A02:2021 | 1 — Signature |

To add a new plugin, create `dast/plugins/myplugin/plugin.yaml` and `detect.py`. The engine loads it automatically on next run — no code changes required.

### Validation Levels

| Level | Meaning | Confidence |
|-------|---------|------------|
| 0 | Unverified — version/pattern match only | Low |
| 1 | Signature Matched — server responded with error/pattern | Medium |
| 2 | Exploitability Demonstrated — canary reflected or OOB callback received | High |

---

## Safety Guardrails

The scanner enforces the following unconditionally:

- **Scope enforcement** — every outbound request is checked against `include`/`exclude` URL patterns; out-of-scope URLs are blocked and logged
- **Destructive payload blocklist** — any payload containing `DROP`, `DELETE`, `TRUNCATE`, `/bin/sh`, `rm -rf`, reverse shell patterns, etc. is silently refused (logged as `payload_blocked`)
- **Rate limiting** — token-bucket QPS cap (default: 5 req/s)
- **Concurrency cap** — semaphore limiting parallel in-flight requests (default: 5)
- **Audit log** — every request and blocked event written to append-only JSONL
- **Abort** — `Ctrl-C` or `dast abort` drains in-flight requests and writes `scan_aborted` to the audit log

---

## CI/CD Integration

```yaml
# GitHub Actions example
- name: Run DAST scan
  run: |
    pip install -r requirements.txt
    python -m dast.cli scan \
      --config scan.yaml \
      --out reports \
      --fail-on high
  # Exit code 1 if any High or Critical finding is introduced

- name: Upload SARIF to GitHub Security
  uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: reports/scan-001.sarif
```

---

## Project Structure

```
dast-demo/
├── docker-compose.yml       # juiceshop + oob-server + scanner
├── oob_server.py            # lightweight OOB callback HTTP server
├── Dockerfile               # scanner image
├── requirements.txt
├── scan.yaml                # scan 1 config (baseline)
├── scan2.yaml               # scan 2 config (simulated fix)
├── scripts/
│   ├── scan1.sh             # run scan 1
│   └── scan2.sh             # run scan 2 + diff
├── reports/                 # scan output (gitignored)
└── dast/
    ├── cli.py               # Click CLI
    ├── engine.py            # scan orchestrator
    ├── safety.py            # scope, rate, blocklist, audit
    ├── fingerprint.py       # tech stack detection
    ├── validator.py         # canary token + OOB callback
    ├── crawler/
    │   ├── static.py        # HTML link/form parser
    │   └── headless.py      # Playwright crawler
    ├── report/
    │   ├── sarif.py         # SARIF 2.1.0 emitter
    │   ├── html.py          # HTML report generator
    │   └── diff.py          # scan diff engine
    └── plugins/
        ├── headers/         # Missing security headers
        ├── sqli/            # SQL Injection
        ├── xss/             # Reflected XSS
        ├── ssrf/            # SSRF
        └── sensitive_info/  # Sensitive info exposure
```
