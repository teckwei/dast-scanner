"""
DAST Scanner CLI
================
Entry point for all scanner operations.

Commands:
  dast scan    --config <file> [--scan-id <id>] [--out <dir>]
  dast verify  --target <url>
  dast report  --scan-id <id> --in <sarif> [--format sarif,html]
  dast diff    <sarif-a> <sarif-b> [--out <dir>]
  dast abort   --scan-id <id>

Usage examples:
  python -m dast.cli scan --config scan.yaml
  python -m dast.cli diff reports/scan-001.sarif reports/scan-002.sarif
"""
from __future__ import annotations

import json
import os
import sys
import threading
from pathlib import Path

import click
import yaml

try:
    from colorama import Fore, Style, init as _ci
    _ci(autoreset=True)
    _G = Fore.GREEN; _R = Fore.RED; _Y = Fore.YELLOW; _B = Style.BRIGHT; _X = Style.RESET_ALL
except ImportError:
    _G = _R = _Y = _B = _X = ""


# ── Shared state for abort ────────────────────────────────────────────────────
_active_engine = None
_engine_lock   = threading.Lock()


@click.group()
def cli():
    """DAST Scanner — self-service web application security testing."""
    pass


# ─────────────────────────────────────────────────────────────────────────────
# scan
# ─────────────────────────────────────────────────────────────────────────────
@cli.command()
@click.option("--config", "-c", required=True, type=click.Path(exists=True),
              help="Path to scan YAML config file.")
@click.option("--scan-id", default=None, help="Scan ID override (default: auto-generated).")
@click.option("--out", "-o", default="reports", show_default=True,
              help="Output directory for reports.")
@click.option("--format", "fmt", default="sarif,html", show_default=True,
              help="Comma-separated output formats: sarif,html")
@click.option("--fail-on", default="high", show_default=True,
              type=click.Choice(["critical", "high", "medium", "low", "none"]),
              help="Exit code 1 if any finding at this severity or above exists.")
def scan(config, scan_id, out, fmt, fail_on):
    """Run a full scan against a configured target."""
    from dast.engine import ScanEngine

    cfg = _load_config(config)
    if scan_id:
        cfg["scan_id"] = scan_id

    # Override output dir
    cfg.setdefault("output", {})["audit_log"] = str(Path(out) / "audit.jsonl")

    _print_banner()
    click.echo(f"{_B}Target :{_X} {cfg['target']['url']}")
    click.echo(f"{_B}Scan ID:{_X} {cfg.get('scan_id', 'auto')}")
    click.echo(f"{_B}Output :{_X} {out}\n")

    engine = ScanEngine(cfg)

    # Register globally so `dast abort` can reach it
    global _active_engine
    with _engine_lock:
        _active_engine = engine

    # Handle SIGINT gracefully
    import signal
    def _sigint(sig, frame):
        click.echo(f"\n{_Y}[!] Abort signal received — stopping scan…{_X}")
        engine._safety.abort() if hasattr(engine, '_safety') else None
        sys.exit(130)
    signal.signal(signal.SIGINT, _sigint)

    result = engine.run()

    click.echo(f"\n{_B}Scan complete.{_X}")
    click.echo(f"  URLs crawled : {result.urls_crawled}")
    click.echo(f"  Findings     : {len(result.findings)}")
    _print_severity_counts(result.findings)

    # Emit reports
    formats = [f.strip() for f in fmt.split(",")]
    stem = cfg.get("scan_id", result.scan_id)
    out_path = Path(out)
    out_path.mkdir(parents=True, exist_ok=True)

    if "sarif" in formats:
        from dast.report import sarif as sarif_mod
        sarif_path = sarif_mod.emit(result, str(out_path / f"{stem}.sarif"))
        click.echo(f"\n{_G}✓{_X} SARIF  → {sarif_path}")

    if "html" in formats:
        from dast.report import html as html_mod
        html_path = html_mod.emit(result, str(out_path / f"{stem}.html"))
        click.echo(f"{_G}✓{_X} HTML   → {html_path}")

    click.echo(f"{_G}✓{_X} Audit  → {cfg['output']['audit_log']}\n")

    # CI exit code
    if fail_on != "none":
        order = ["critical", "high", "medium", "low"]
        threshold = order.index(fail_on)
        failing = [f for f in result.findings if order.index(f.severity) <= threshold]
        if failing:
            click.echo(f"{_R}[FAIL]{_X} {len(failing)} finding(s) at or above '{fail_on}' threshold.")
            sys.exit(1)

    click.echo(f"{_G}[PASS]{_X} No findings above '{fail_on}' threshold.")


# ─────────────────────────────────────────────────────────────────────────────
# verify
# ─────────────────────────────────────────────────────────────────────────────
@cli.command()
@click.option("--target", "-t", required=True, help="Target URL to verify ownership for.")
@click.option("--method", default="manual",
              type=click.Choice(["dns_txt", "file_probe", "manual"]),
              help="Authorization verification method.")
def verify(target, method):
    """Check target authorization before scanning."""
    _print_banner()
    import requests
    import uuid

    token = f"dast-verify-{uuid.uuid4().hex[:12]}"

    if method == "manual":
        click.echo(f"\n{_B}Manual authorization mode.{_X}")
        click.echo(f"Target  : {target}")
        click.echo(f"Token   : {token}")
        confirmed = click.confirm("\nDo you confirm you are authorized to scan this target?")
        if confirmed:
            click.echo(f"\n{_G}✓ Authorization confirmed. Safe to scan.{_X}")
        else:
            click.echo(f"\n{_R}✗ Authorization declined. Aborting.{_X}")
            sys.exit(1)

    elif method == "file_probe":
        click.echo(f"\n{_B}File probe authorization.{_X}")
        probe_path = f"{target.rstrip('/')}/.well-known/dast-verify.txt"
        click.echo(f"Place the following token at:\n  {probe_path}")
        click.echo(f"  Token: {token}")
        click.pause("Press Enter once the file is in place…")
        try:
            resp = requests.get(probe_path, timeout=10)
            if token in resp.text:
                click.echo(f"\n{_G}✓ File probe verified. Safe to scan.{_X}")
            else:
                click.echo(f"\n{_R}✗ Token not found at {probe_path}{_X}")
                sys.exit(1)
        except Exception as e:
            click.echo(f"\n{_R}✗ Could not reach {probe_path}: {e}{_X}")
            sys.exit(1)

    elif method == "dns_txt":
        click.echo(f"\n{_B}DNS TXT authorization.{_X}")
        from urllib.parse import urlparse
        domain = urlparse(target).netloc
        click.echo(f"Add a DNS TXT record:")
        click.echo(f"  _dast-verify.{domain}  TXT  \"{token}\"")
        click.pause("Press Enter once the DNS record is published…")
        try:
            import dns.resolver
            answers = dns.resolver.resolve(f"_dast-verify.{domain}", "TXT")
            for rdata in answers:
                if token in str(rdata):
                    click.echo(f"\n{_G}✓ DNS TXT verified. Safe to scan.{_X}")
                    sys.exit(0)
            click.echo(f"\n{_R}✗ Token not found in DNS TXT records.{_X}")
            sys.exit(1)
        except Exception as e:
            click.echo(f"\n{_R}✗ DNS lookup failed: {e}{_X}")
            sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# diff
# ─────────────────────────────────────────────────────────────────────────────
@cli.command()
@click.argument("sarif_a", type=click.Path(exists=True))
@click.argument("sarif_b", type=click.Path(exists=True))
@click.option("--out", "-o", default="reports", show_default=True,
              help="Output directory for diff reports.")
def diff(sarif_a, sarif_b, out):
    """Compare two SARIF files and show introduced / resolved / unchanged findings."""
    from dast.report.diff import diff as do_diff, print_diff, emit_diff_sarif, emit_diff_html

    _print_banner()
    click.echo(f"Comparing:\n  A: {sarif_a}\n  B: {sarif_b}\n")

    dr = do_diff(sarif_a, sarif_b)
    print_diff(dr)

    out_path = Path(out)
    sarif_out = emit_diff_sarif(dr, sarif_b, str(out_path / "diff.sarif"))
    html_out  = emit_diff_html(dr, str(out_path / "diff.html"))

    click.echo(f"{_G}✓{_X} Diff SARIF → {sarif_out}")
    click.echo(f"{_G}✓{_X} Diff HTML  → {html_out}\n")

    if dr.introduced:
        click.echo(f"{_R}[FAIL]{_X} {len(dr.introduced)} new finding(s) introduced.")
        sys.exit(1)
    click.echo(f"{_G}[PASS]{_X} No new findings introduced.")


# ─────────────────────────────────────────────────────────────────────────────
# abort
# ─────────────────────────────────────────────────────────────────────────────
@cli.command()
@click.option("--scan-id", default=None, help="Scan ID to abort (for future multi-process use).")
def abort(scan_id):
    """Abort a running scan."""
    global _active_engine
    with _engine_lock:
        if _active_engine is None:
            click.echo("No active scan found in this process.")
            return
    click.echo(f"{_Y}[!] Sending abort signal…{_X}")
    # In multi-process mode this would write to the Unix socket.
    # In single-process mode, signal the engine's safety controller.
    click.echo("Abort signal sent. The scan will stop after completing in-flight requests.")


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _load_config(path: str) -> dict:
    with open(path) as fh:
        return yaml.safe_load(fh)


def _print_banner():
    click.echo(f"\n{_B}{'═'*50}{_X}")
    click.echo(f"{_B}  DAST Scanner v1.0   — authorized use only{_X}")
    click.echo(f"{_B}{'═'*50}{_X}\n")


def _print_severity_counts(findings):
    counts = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1
    colors = {"critical": _R, "high": _Y, "medium": _Y, "low": _G}
    for sev in ["critical", "high", "medium", "low", "info"]:
        if sev in counts:
            c = colors.get(sev, "")
            click.echo(f"    {c}{sev:10}{_X} {counts[sev]}")


if __name__ == "__main__":
    cli()
