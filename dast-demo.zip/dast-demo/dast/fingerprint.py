"""
Technology Fingerprinter
========================
Identifies front-end frameworks, back-end languages, middleware,
CMS, and third-party component versions from HTTP responses.

Signals used (in priority order):
  1. Response headers  (Server, X-Powered-By, X-AspNet-Version, …)
  2. Cookie names      (PHPSESSID → PHP, JSESSIONID → Java, …)
  3. HTML meta tags    (<meta name="generator" …>)
  4. Known path probes (/.wp-login.php, /_next/static, …)
  5. JS globals in page source (window.React, window.angular, …)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

import requests
from bs4 import BeautifulSoup


@dataclass
class Fingerprint:
    server: Optional[str] = None
    language: Optional[str] = None
    framework: Optional[str] = None
    cms: Optional[str] = None
    js_libs: list[str] = field(default_factory=list)
    raw_tags: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "server": self.server,
            "language": self.language,
            "framework": self.framework,
            "cms": self.cms,
            "js_libs": self.js_libs,
            "raw_tags": self.raw_tags,
        }


# ── Signal tables ─────────────────────────────────────────────────────────────

_HEADER_RULES: list[tuple[str, str, str, str]] = [
    # (header_name, pattern, category, label)
    ("server",          r"nginx/([\d.]+)",         "server",    "nginx/{1}"),
    ("server",          r"Apache/([\d.]+)",         "server",    "Apache/{1}"),
    ("server",          r"Microsoft-IIS/([\d.]+)",  "server",    "IIS/{1}"),
    ("x-powered-by",    r"PHP/([\d.]+)",            "language",  "PHP/{1}"),
    ("x-powered-by",    r"ASP\.NET",                "language",  "ASP.NET"),
    ("x-powered-by",    r"Express",                 "framework", "Express.js"),
    ("x-aspnet-version",r"([\d.]+)",                "language",  "ASP.NET/{1}"),
    ("x-generator",     r"(.*)",                    "cms",       "{1}"),
]

_COOKIE_RULES: list[tuple[str, str, str]] = [
    ("PHPSESSID",   "language",  "PHP"),
    ("JSESSIONID",  "language",  "Java/Servlet"),
    ("ASP.NET_SessionId", "language", "ASP.NET"),
    ("laravel_session", "framework", "Laravel"),
    ("_rails",      "framework", "Ruby on Rails"),
    ("connect.sid", "framework", "Express.js/connect"),
]

_PATH_PROBES: list[tuple[str, str, str]] = [
    ("/wp-login.php",           "cms",       "WordPress"),
    ("/wp-content/",            "cms",       "WordPress"),
    ("/_next/static/",          "framework", "Next.js"),
    ("/__nuxt/",                "framework", "Nuxt.js"),
    ("/vendor/laravel/",        "framework", "Laravel"),
    ("/rails/info/",            "framework", "Ruby on Rails"),
    ("/struts/",                "framework", "Apache Struts"),
    ("/Telerik.Web.UI.WebResource.axd", "framework", "Telerik ASP.NET"),
]

_JS_GLOBALS: list[tuple[str, str]] = [
    (r"window\.React\b",           "React"),
    (r"window\.angular\b",         "AngularJS"),
    (r"window\.Vue\b",             "Vue.js"),
    (r'"next":\s*"[\d.]+?"',       "Next.js"),
    (r"__ember[A-Z]",              "Ember.js"),
    (r"Backbone\.VERSION",         "Backbone.js"),
    (r"jQuery\.fn\.jquery",        "jQuery"),
]


# ── Main fingerprinter ────────────────────────────────────────────────────────

class Fingerprinter:
    def __init__(self, session: requests.Session, base_url: str):
        self._session = session
        self._base = base_url.rstrip("/")

    def run(self) -> Fingerprint:
        fp = Fingerprint()
        try:
            resp = self._session.get(self._base, timeout=10, allow_redirects=True)
        except Exception:
            return fp

        self._from_headers(resp, fp)
        self._from_cookies(resp, fp)
        self._from_html(resp.text, fp)
        self._from_js_globals(resp.text, fp)
        return fp

    def _from_headers(self, resp: requests.Response, fp: Fingerprint):
        for header, pattern, category, label_tpl in _HEADER_RULES:
            value = resp.headers.get(header, "")
            m = re.search(pattern, value, re.IGNORECASE)
            if m:
                label = label_tpl
                for i, grp in enumerate(m.groups(), 1):
                    label = label.replace(f"{{{i}}}", grp or "")
                fp.raw_tags[header] = label
                if category == "server":    fp.server    = fp.server    or label
                if category == "language":  fp.language  = fp.language  or label
                if category == "framework": fp.framework = fp.framework or label
                if category == "cms":       fp.cms       = fp.cms       or label

    def _from_cookies(self, resp: requests.Response, fp: Fingerprint):
        for cookie_name, category, label in _COOKIE_RULES:
            if cookie_name in resp.cookies:
                fp.raw_tags[f"cookie:{cookie_name}"] = label
                if category == "language":  fp.language  = fp.language  or label
                if category == "framework": fp.framework = fp.framework or label

    def _from_html(self, html: str, fp: Fingerprint):
        try:
            soup = BeautifulSoup(html, "lxml")
        except Exception:
            return
        gen = soup.find("meta", attrs={"name": "generator"})
        if gen and gen.get("content"):
            fp.cms = fp.cms or gen["content"]
            fp.raw_tags["meta:generator"] = gen["content"]

    def _from_js_globals(self, html: str, fp: Fingerprint):
        for pattern, lib_name in _JS_GLOBALS:
            if re.search(pattern, html):
                if lib_name not in fp.js_libs:
                    fp.js_libs.append(lib_name)
