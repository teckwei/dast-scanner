"""
Headless Browser Crawler
========================
Uses Playwright (Chromium) to:
  1. Render JS-heavy / SPA pages
  2. Intercept XHR / fetch calls → discovers API endpoints not visible in HTML
  3. Run optional login scripts to maintain authenticated sessions
  4. Capture a HAR-like list of observed network requests

Falls back gracefully if Playwright is not installed.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urlparse, urldefrag

from dast.safety import SafetyController


@dataclass
class HeadlessResult:
    rendered_urls: list[str] = field(default_factory=list)
    api_endpoints: list[dict] = field(default_factory=list)  # {url, method}
    cookies: list[dict] = field(default_factory=list)


class HeadlessCrawler:
    """
    Renders a set of seed URLs with a headless Chromium instance.

    login_script: list of step dicts, e.g.
      [{"action": "fill",  "selector": "#email",    "value": "test@test.com"},
       {"action": "fill",  "selector": "#password",  "value": "P@ssword1"},
       {"action": "click", "selector": "button[type=submit]"},
       {"action": "wait_for", "selector": ".dashboard"}]
    """

    def __init__(
        self,
        safety: SafetyController,
        base_url: str,
        login_script: Optional[list[dict]] = None,
        max_pages: int = 50,
    ):
        self._safety = safety
        self._base = base_url.rstrip("/")
        self._origin = urlparse(base_url).netloc
        self._login_script = login_script or []
        self._max_pages = max_pages

    def crawl(self, seed_urls: list[str]) -> HeadlessResult:
        try:
            from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
        except ImportError:
            print("[headless] playwright not installed — skipping headless crawl")
            return HeadlessResult()

        result = HeadlessResult()
        visited: set[str] = set()
        api_seen: set[str] = set()

        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            ctx = browser.new_context(ignore_https_errors=True)

            # Intercept all network requests to discover API endpoints
            def _on_request(request):
                url, _ = urldefrag(request.url)
                parsed = urlparse(url)
                if parsed.netloc == self._origin and url not in api_seen:
                    api_seen.add(url)
                    result.api_endpoints.append(
                        {"url": url, "method": request.method}
                    )

            ctx.on("request", _on_request)
            page = ctx.new_page()

            # Run login script if provided
            if self._login_script:
                self._run_login(page, self._base)

            # Capture session cookies after login
            result.cookies = ctx.cookies()

            # Crawl seed URLs
            queue = list(seed_urls[:self._max_pages])
            while queue and len(visited) < self._max_pages:
                url = queue.pop(0)
                url, _ = urldefrag(url)
                if url in visited:
                    continue
                if not self._safety.allow_url(url + "*"):
                    continue
                visited.add(url)
                try:
                    page.goto(url, wait_until="networkidle", timeout=15_000)
                    result.rendered_urls.append(url)
                    # Collect new links surfaced after JS render
                    links = page.eval_on_selector_all(
                        "a[href]",
                        "els => els.map(e => e.href)",
                    )
                    for link in links:
                        link, _ = urldefrag(link)
                        if (
                            urlparse(link).netloc == self._origin
                            and link not in visited
                        ):
                            queue.append(link)
                except Exception:
                    pass

            browser.close()

        return result

    def _run_login(self, page, base_url: str):
        try:
            page.goto(base_url, wait_until="networkidle", timeout=15_000)
            for step in self._login_script:
                action = step.get("action")
                sel = step.get("selector", "")
                if action == "fill":
                    page.fill(sel, step.get("value", ""))
                elif action == "click":
                    page.click(sel)
                elif action == "wait_for":
                    page.wait_for_selector(sel, timeout=8_000)
                elif action == "navigate":
                    page.goto(step.get("url", base_url), wait_until="networkidle")
        except Exception as e:
            print(f"[headless] login script error: {e}")
