"""
Static Crawler
==============
Parses HTML pages to extract:
  - Anchor links  (<a href>)
  - Form actions  (<form action> + input/select names)
  - Script / link asset URLs
  - Inline fetch/XHR URL strings (simple regex heuristic)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urljoin, urlparse, urldefrag

import requests
from bs4 import BeautifulSoup

from dast.safety import SafetyController


@dataclass
class FormEntry:
    action: str
    method: str                          # GET | POST
    fields: list[dict]                   # [{"name": "q", "type": "text"}, …]


@dataclass
class CrawlResult:
    urls: list[str] = field(default_factory=list)
    forms: list[FormEntry] = field(default_factory=list)
    api_hints: list[str] = field(default_factory=list)   # URL strings found in JS


# Regex to extract quoted URLs from inline JS  (conservative)
_JS_URL_RE = re.compile(
    r"""['"]((?:https?://[^\s'"<>]+|/[a-zA-Z0-9_\-/?.=&%#+]+))['"]]?""",
    re.MULTILINE,
)


class StaticCrawler:
    def __init__(
        self,
        session: requests.Session,
        safety: SafetyController,
        base_url: str,
        max_pages: int = 150,
    ):
        self._session = session
        self._safety = safety
        self._base = base_url.rstrip("/")
        self._max_pages = max_pages
        self._origin = urlparse(base_url).netloc
        self._visited: set[str] = set()
        self._queue: list[str] = [self._base]

    def crawl(self) -> CrawlResult:
        result = CrawlResult()
        while self._queue and len(self._visited) < self._max_pages:
            url = self._queue.pop(0)
            url, _ = urldefrag(url)   # strip fragment
            if url in self._visited:
                continue
            if not self._safety.allow_url(url):
                continue
            self._visited.add(url)
            result.urls.append(url)
            self._fetch_and_parse(url, result)
        return result

    def _fetch_and_parse(self, url: str, result: CrawlResult):
        try:
            self._safety.acquire()
            resp = self._session.get(url, timeout=10, allow_redirects=True)
            self._safety.release()
        except Exception:
            self._safety.release()
            return

        ct = resp.headers.get("content-type", "")
        if "html" not in ct:
            return

        soup = BeautifulSoup(resp.text, "lxml")
        self._extract_links(soup, url, result)
        self._extract_forms(soup, url, result)
        self._extract_js_urls(soup, url, result)

    def _extract_links(self, soup: BeautifulSoup, page_url: str, result: CrawlResult):
        for tag in soup.find_all(["a", "link"], href=True):
            href = tag["href"].strip()
            abs_url = urljoin(page_url, href)
            abs_url, _ = urldefrag(abs_url)
            if self._is_same_origin(abs_url) and abs_url not in self._visited:
                self._queue.append(abs_url)

    def _extract_forms(self, soup: BeautifulSoup, page_url: str, result: CrawlResult):
        for form in soup.find_all("form"):
            action = form.get("action", page_url)
            abs_action = urljoin(page_url, action)
            method = (form.get("method") or "GET").upper()
            fields = []
            for inp in form.find_all(["input", "select", "textarea"]):
                name = inp.get("name")
                if name:
                    fields.append({
                        "name": name,
                        "type": inp.get("type", "text"),
                        "value": inp.get("value", ""),
                    })
            result.forms.append(FormEntry(action=abs_action, method=method, fields=fields))

    def _extract_js_urls(self, soup: BeautifulSoup, page_url: str, result: CrawlResult):
        for script in soup.find_all("script"):
            text = script.string or ""
            for m in _JS_URL_RE.finditer(text):
                candidate = m.group(1)
                abs_url = urljoin(page_url, candidate)
                if self._is_same_origin(abs_url):
                    if abs_url not in result.api_hints:
                        result.api_hints.append(abs_url)

    def _is_same_origin(self, url: str) -> bool:
        parsed = urlparse(url)
        return parsed.netloc == self._origin or parsed.netloc == ""
