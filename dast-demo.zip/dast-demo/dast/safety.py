"""
Safety & Control Plane
======================
A singleton SafetyController wraps every outbound HTTP request.

Responsibilities:
  - Scope enforcement  : block requests outside declared in/exclude patterns
  - Rate limiting      : token-bucket QPS cap (configurable per scan)
  - Concurrency cap    : semaphore limiting parallel in-flight requests
  - Destructive payload blocklist: refuse payloads tagged destructive=true
  - Audit logging      : every request attempt logged to append-only JSONL
  - Abort channel      : call abort() to halt all future requests immediately
"""

from __future__ import annotations

import fnmatch
import json
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


# ── Destructive payload patterns (refused unconditionally) ────────────────────
_DESTRUCTIVE_SQL = [
    "DROP ", "DELETE ", "TRUNCATE ", "UPDATE ", "INSERT ",
    "ALTER ", "CREATE ", "GRANT ", "REVOKE ",
]
_DESTRUCTIVE_OS = [
    "rm -rf", "/bin/sh", "/bin/bash", "cmd.exe", "powershell",
    "wget http", "curl http", "nc -e", "bash -i",
    "> /etc", ">> /etc",
]
_DESTRUCTIVE_PATTERNS = [p.upper() for p in _DESTRUCTIVE_SQL + _DESTRUCTIVE_OS]


@dataclass
class SafetyConfig:
    include_patterns: list[str] = field(default_factory=list)   # URL globs
    exclude_patterns: list[str] = field(default_factory=list)   # URL globs
    max_qps: float = 5.0
    max_concurrency: int = 5
    audit_log_path: str = "reports/audit.jsonl"


class SafetyController:
    """Thread-safe safety controller.  Instantiated once per scan session."""

    def __init__(self, config: SafetyConfig):
        self._config = config
        self._aborted = False
        self._lock = threading.Lock()
        self._semaphore = threading.Semaphore(config.max_concurrency)

        # Token-bucket rate limiter
        self._tokens = config.max_qps
        self._max_tokens = config.max_qps
        self._last_refill = time.monotonic()
        self._rate_lock = threading.Lock()

        # Audit log
        audit_path = Path(config.audit_log_path)
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        self._audit_fh = open(audit_path, "a", buffering=1)  # line-buffered

    # ── Public API ────────────────────────────────────────────────────────────

    def allow_url(self, url: str) -> bool:
        """Return True if url is within declared scope."""
        cfg = self._config
        # Match url as-is, or with trailing slash stripped/added (base URL edge case)
        candidates = {url, url.rstrip("/"), url.rstrip("/") + "/"}
        in_scope = any(
            fnmatch.fnmatch(candidate, p)
            for candidate in candidates
            for p in cfg.include_patterns
        )
        excluded = any(
            fnmatch.fnmatch(candidate, p)
            for candidate in candidates
            for p in cfg.exclude_patterns
        )
        allowed = in_scope and not excluded
        if not allowed:
            self._audit("url_blocked", url=url, reason="out_of_scope")
        return allowed

    def check_payload(self, payload: str, plugin_id: str) -> bool:
        """Return True if payload passes the destructive blocklist."""
        upper = payload.upper()
        for pattern in _DESTRUCTIVE_PATTERNS:
            if pattern in upper:
                self._audit(
                    "payload_blocked",
                    plugin=plugin_id,
                    payload_preview=payload[:120],
                    reason=f"destructive_pattern:{pattern.strip()}",
                )
                return False
        return True

    def acquire(self):
        """Block until rate + concurrency budget allows another request."""
        if self._aborted:
            raise AbortedError("scan aborted")
        self._rate_wait()
        self._semaphore.acquire()

    def release(self):
        self._semaphore.release()

    def log_request(self, url: str, plugin_id: str, payload_id: str, blocked: bool = False):
        self._audit(
            "request_sent" if not blocked else "request_blocked",
            url=url,
            plugin=plugin_id,
            payload_id=payload_id,
            blocked=blocked,
        )

    def abort(self):
        with self._lock:
            self._aborted = True
        self._audit("scan_aborted")
        self._audit_fh.flush()

    @property
    def is_aborted(self) -> bool:
        return self._aborted

    def close(self):
        self._audit_fh.flush()
        self._audit_fh.close()

    # ── Internals ─────────────────────────────────────────────────────────────

    def _rate_wait(self):
        """Token-bucket: block until a token is available."""
        while True:
            with self._rate_lock:
                now = time.monotonic()
                elapsed = now - self._last_refill
                self._tokens = min(
                    self._max_tokens,
                    self._tokens + elapsed * self._max_tokens,
                )
                self._last_refill = now
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return
            time.sleep(0.05)

    def _audit(self, event_type: str, **kwargs):
        entry = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "type": event_type,
            **kwargs,
        }
        self._audit_fh.write(json.dumps(entry) + "\n")


class AbortedError(RuntimeError):
    pass
