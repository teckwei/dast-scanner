"""
Plugin-based Detection Engine
==============================
Orchestrates the full scan lifecycle:

  1. Authorize target
  2. Crawl (static + headless)
  3. Fingerprint technology stack
  4. Route discovered URLs/forms to active plugins
  5. Collect findings with validation level tags
  6. Return structured ScanResult

Plugin discovery is automatic: any subdirectory of dast/plugins/ that
contains both plugin.yaml and detect.py is loaded at startup.
"""
from __future__ import annotations

import importlib.util
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import requests
import yaml

from dast.safety import SafetyController, SafetyConfig
from dast.fingerprint import Fingerprinter
from dast.crawler.static import StaticCrawler
from dast.crawler.headless import HeadlessCrawler
from dast.validator import make_canary


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass
class Finding:
    id: str
    plugin_id: str
    title: str
    severity: str                 # critical | high | medium | low | info
    validation_level: int         # 0=unverified 1=signature 2=exploited
    url: str
    parameter: Optional[str]
    method: str
    evidence: dict
    reproduction: str
    impact: str
    remediation: str
    cwe: str
    owasp: str
    owner_hint: str = ""
    scan_id: str = ""
    first_seen: str = ""

    def to_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class ScanResult:
    scan_id: str
    target: str
    started_at: str
    finished_at: str = ""
    fingerprint: dict = field(default_factory=dict)
    urls_crawled: int = 0
    findings: list[Finding] = field(default_factory=list)
    aborted: bool = False

    def to_dict(self) -> dict:
        d = self.__dict__.copy()
        d["findings"] = [f.to_dict() for f in self.findings]
        return d


# ── Plugin loader ─────────────────────────────────────────────────────────────

def _load_plugins(plugin_dir: Path) -> list[dict]:
    """
    Returns list of plugin descriptors:
      {"meta": {...yaml...}, "module": <loaded module>}
    """
    plugins = []
    for subdir in sorted(plugin_dir.iterdir()):
        yaml_file = subdir / "plugin.yaml"
        detect_file = subdir / "detect.py"
        if not (yaml_file.exists() and detect_file.exists()):
            continue
        meta = yaml.safe_load(yaml_file.read_text())
        spec = importlib.util.spec_from_file_location(
            f"dast.plugins.{subdir.name}.detect", detect_file
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        plugins.append({"meta": meta, "module": mod})
        print(f"[engine] loaded plugin: {meta['id']} — {meta['name']}")
    return plugins


# ── Engine ────────────────────────────────────────────────────────────────────

class ScanEngine:
    def __init__(self, config: dict):
        self._cfg = config
        self._plugins_dir = Path(__file__).parent / "plugins"
        self._plugins = _load_plugins(self._plugins_dir)

    def run(self) -> ScanResult:
        cfg = self._cfg
        scan_id = cfg.get("scan_id", f"scan-{uuid.uuid4().hex[:8]}")
        target_url = cfg["target"]["url"].rstrip("/")

        result = ScanResult(
            scan_id=scan_id,
            target=target_url,
            started_at=_now(),
        )

        # ── Safety controller ─────────────────────────────────────────────────
        scope_cfg = cfg["target"].get("scope", {})
        include_patterns = scope_cfg.get("include", [f"{target_url}*"])
        exclude_patterns = scope_cfg.get("exclude", [])
        rate_cfg = cfg.get("rate_limits", {})
        safety_config = SafetyConfig(
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
            max_qps=rate_cfg.get("max_qps", 5.0),
            max_concurrency=rate_cfg.get("max_concurrency", 5),
            audit_log_path=cfg.get("output", {}).get("audit_log", "reports/audit.jsonl"),
        )
        safety = SafetyController(safety_config)

        # ── HTTP session ──────────────────────────────────────────────────────
        session = requests.Session()
        session.headers.update({
            "User-Agent": "DAST-Scanner/1.0 (authorized-security-test)",
        })
        extra_headers = cfg.get("http", {}).get("headers", {})
        session.headers.update(extra_headers)

        try:
            # ── Fingerprint ───────────────────────────────────────────────────
            print(f"[engine] fingerprinting {target_url}")
            fp = Fingerprinter(session, target_url).run()
            result.fingerprint = fp.to_dict()
            print(f"[engine] fingerprint: {fp.to_dict()}")

            # ── Static crawl ──────────────────────────────────────────────────
            print(f"[engine] static crawl starting")
            static_cfg = cfg.get("crawl", {})
            static_crawler = StaticCrawler(
                session=session,
                safety=safety,
                base_url=target_url,
                max_pages=static_cfg.get("max_pages", 100),
            )
            # Inject seed URLs (manually declared API endpoints)
            for seed in cfg.get("seed_urls", []):
                if seed not in static_crawler._queue:
                    static_crawler._queue.append(seed)
            crawl_result = static_crawler.crawl()
            print(f"[engine] static crawl: {len(crawl_result.urls)} URLs, {len(crawl_result.forms)} forms")

            # ── Headless crawl (optional) ─────────────────────────────────────
            if cfg.get("crawl", {}).get("headless", False):
                print(f"[engine] headless crawl starting")
                login_script = cfg.get("auth", {}).get("login_script")
                hc = HeadlessCrawler(
                    safety=safety,
                    base_url=target_url,
                    login_script=login_script,
                    max_pages=static_cfg.get("headless_max_pages", 30),
                )
                hresult = hc.crawl(crawl_result.urls[:20])
                # Merge newly discovered API endpoints into URLs
                for ep in hresult.api_endpoints:
                    if ep["url"] not in crawl_result.urls:
                        crawl_result.urls.append(ep["url"])
                print(f"[engine] headless: {len(hresult.rendered_urls)} rendered, "
                      f"{len(hresult.api_endpoints)} API endpoints discovered")

            result.urls_crawled = len(crawl_result.urls)

            # ── Plugin dispatch ───────────────────────────────────────────────
            all_findings: list[dict] = []

            for plugin in self._plugins:
                if safety.is_aborted:
                    result.aborted = True
                    break
                meta = plugin["meta"]
                mod = plugin["module"]
                print(f"[engine] running plugin {meta['id']} against {len(crawl_result.urls)} URLs")

                for url in crawl_result.urls:
                    if safety.is_aborted:
                        break
                    if not safety.allow_url(url):
                        continue
                    # Gather forms relevant to this URL
                    forms = [
                        f.__dict__ for f in crawl_result.forms
                        if f.action.startswith(target_url)
                    ] if hasattr(crawl_result.forms[0] if crawl_result.forms else None, "__dict__") else []

                    # Convert FormEntry objects to plain dicts
                    forms_dicts = []
                    for f in crawl_result.forms:
                        if f.action.startswith(target_url):
                            forms_dicts.append({
                                "action": f.action,
                                "method": f.method,
                                "fields": f.fields,
                            })

                    try:
                        raw = mod.run(
                            url=url,
                            session=session,
                            safety=safety,
                            forms=forms_dicts,
                        )
                        all_findings.extend(raw or [])
                    except Exception as e:
                        print(f"[engine] plugin {meta['id']} error on {url}: {e}")

            # ── Convert dicts → Finding objects ───────────────────────────────
            for i, f in enumerate(all_findings):
                result.findings.append(Finding(
                    id=f"FIND-{i+1:04d}",
                    scan_id=scan_id,
                    first_seen=_now(),
                    plugin_id=f.get("plugin_id", ""),
                    title=f.get("title", ""),
                    severity=f.get("severity", "info"),
                    validation_level=f.get("validation_level", 0),
                    url=f.get("url", ""),
                    parameter=f.get("parameter"),
                    method=f.get("method", "GET"),
                    evidence=f.get("evidence", {}),
                    reproduction=f.get("reproduction", ""),
                    impact=f.get("impact", ""),
                    remediation=f.get("remediation", ""),
                    cwe=f.get("cwe", ""),
                    owasp=f.get("owasp", ""),
                    owner_hint=f.get("owner_hint", ""),
                ))

        finally:
            safety.close()
            result.finished_at = _now()

        return result


def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
