"""
Exploitability Validator
========================
Tracks two validation mechanisms:

1. Canary Token Reflection  (XSS, template injection, …)
   - Scanner plants a unique string in a request parameter
   - If the string appears verbatim in the response body → reflected → Level 2

2. Out-of-Band (OOB) Callback  (SSRF, blind SQLi, XXE, …)
   - Scanner registers a token with the OOB server
   - Payload encodes a URL that, when fetched by the target, hits OOB server
   - Validator polls the OOB server to check if the callback was received
"""
from __future__ import annotations

import time
import uuid
import os

import requests


OOB_HOST = os.environ.get("OOB_HOST", "localhost")
OOB_PORT = int(os.environ.get("OOB_PORT", "8877"))
OOB_BASE = f"http://{OOB_HOST}:{OOB_PORT}"


def make_canary() -> str:
    """Return a unique string to plant in a request and look for in responses."""
    return f"DAST-CANARY-{uuid.uuid4().hex[:12]}"


def check_canary(canary: str, response_text: str) -> bool:
    """Return True if canary appears verbatim in the response body."""
    return canary in response_text


def make_oob_token() -> str:
    """Return a unique OOB token.  The callback URL is oob_callback_url()."""
    return uuid.uuid4().hex


def oob_callback_url(token: str) -> str:
    """URL the vulnerable server should fetch (encodes the proof of SSRF)."""
    return f"{OOB_BASE}/cb/{token}"


def poll_oob(token: str, timeout: float = 8.0, interval: float = 0.5) -> bool:
    """
    Poll the OOB server until the callback is received or timeout expires.
    Returns True if callback was received.
    """
    deadline = time.monotonic() + timeout
    url = f"{OOB_BASE}/poll/{token}"
    while time.monotonic() < deadline:
        try:
            resp = requests.get(url, timeout=3)
            if resp.json().get("received"):
                return True
        except Exception:
            pass
        time.sleep(interval)
    return False
