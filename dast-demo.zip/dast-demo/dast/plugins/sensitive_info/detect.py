"""
Sensitive Information Exposure Plugin (Passive, Level 1)
=========================================================
Scans HTTP response bodies for patterns that indicate accidental
disclosure of secrets, stack traces, credentials, or internal paths.

No requests beyond a normal GET are made — this is a passive check.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import requests


PLUGIN_ID = "SENSINFO-001"

# (pattern, title, severity, remediation)
_PATTERNS: list[tuple[re.Pattern, str, str, str]] = [
    (
        re.compile(r"(?i)(stack\s*trace|traceback\s*\(most\s*recent|at\s+\w[\w.]+\.\w+\([\w.]+:\d+\))"),
        "Stack trace / exception detail exposed",
        "medium",
        "Suppress detailed error messages in production. Return a generic error page instead. "
        "Configure your framework's error handling to hide internal paths and class names.",
    ),
    (
        re.compile(r"(?i)(password|passwd|secret|api[_-]?key|auth[_-]?token)\s*[=:]\s*['\"]?[^\s'\"<]{6,}"),
        "Credential or secret value in response body",
        "critical",
        "Remove credentials from HTTP responses immediately. Rotate any exposed secrets. "
        "Use environment variables and secrets managers — never return them in API responses.",
    ),
    (
        re.compile(r"(?i)(mongodb://|postgresql://|mysql://|redis://|amqp://)[^\s'\"<]{8,}"),
        "Database connection string exposed",
        "critical",
        "Remove all connection strings from HTTP responses. Rotate credentials immediately.",
    ),
    (
        re.compile(r"(?i)(\bAIza[0-9A-Za-z\-_]{35}\b|AKIA[0-9A-Z]{16}|sk-[a-zA-Z0-9]{32,})"),
        "Cloud / AI API key exposed (Google / AWS / OpenAI pattern)",
        "critical",
        "Revoke and rotate the exposed key immediately. Never embed API keys in client-facing responses.",
    ),
    (
        re.compile(r"(?i)(php\s+fatal|parse\s+error|uncaught\s+exception|warning:\s+\w+\(\))"),
        "PHP error or warning exposed",
        "medium",
        "Set display_errors=Off in php.ini for production. Log errors to a file, not to the browser.",
    ),
    (
        re.compile(r"(?i)(<!--.*?--\s*>)", re.DOTALL),
        "HTML comment with potentially sensitive content",
        "low",
        "Review and remove HTML comments containing internal paths, version numbers, "
        "or developer notes before deploying to production.",
    ),
    (
        re.compile(r"(?i)(\/etc\/passwd|\/etc\/shadow|c:\\windows\\system32)"),
        "Internal filesystem path disclosed",
        "high",
        "Do not include filesystem paths in error messages or API responses.",
    ),
]


def run(url: str, session: requests.Session, safety=None, forms=None) -> list[dict]:
    try:
        if safety:
            safety.acquire()
        resp = session.get(url, timeout=10)
        if safety:
            safety.release()
    except Exception:
        if safety:
            safety.release()
        return []

    findings = []
    for pattern, title, severity, remediation in _PATTERNS:
        m = pattern.search(resp.text)
        if m:
            findings.append({
                "plugin_id":        PLUGIN_ID,
                "title":            title,
                "severity":         severity,
                "validation_level": 1,
                "url":              url,
                "parameter":        None,
                "method":           "GET",
                "evidence": {
                    "matched_pattern": pattern.pattern,
                    "response_excerpt": _excerpt_around(m.group(0), resp.text),
                },
                "reproduction":     f"curl '{url}'  # inspect the response body",
                "impact": (
                    "Exposed internal information assists attackers in targeting "
                    "further attacks with knowledge of technology stack, credentials, or paths."
                ),
                "remediation": remediation,
                "cwe":   "CWE-200",
                "owasp": "A02:2021",
            })
    return findings


def _excerpt_around(match_text: str, body: str, window: int = 300) -> str:
    idx = body.find(match_text)
    if idx == -1:
        return match_text[:300]
    start = max(0, idx - window // 2)
    end = min(len(body), idx + len(match_text) + window // 2)
    return body[start:end]
