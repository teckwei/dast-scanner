"""
SQL Injection Plugin (Error-based, Level 1)
===========================================
Appends SQL error-triggering payloads to URL query parameters and form
fields.  If a known database error message appears in the response body
the finding is marked validation_level=1 (Signature Matched).

No destructive payloads (no DROP / DELETE / UPDATE) are sent.
"""
from __future__ import annotations

import copy
from urllib.parse import urlencode, parse_qs, urlparse, urlunparse

import requests
import yaml
from pathlib import Path


PLUGIN_ID = "SQLI-001"
_META = yaml.safe_load((Path(__file__).parent / "plugin.yaml").read_text())
_PAYLOADS = _META["payloads"]
_SIGS = [s.lower() for s in _META["error_signatures"]]


def run(url: str, session: requests.Session, safety=None, forms=None) -> list[dict]:
    findings = []
    findings += _test_url_params(url, session, safety)
    for form in (forms or []):
        if form.get("action") and _same_origin(url, form["action"]):
            findings += _test_form(form, session, safety)
    return _dedup(findings)


def _test_url_params(url: str, session: requests.Session, safety) -> list[dict]:
    parsed = urlparse(url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    if not params:
        return []

    findings = []
    for param_name in params:
        for payload_meta in _PAYLOADS:
            payload = payload_meta["value"]
            if safety and not safety.check_payload(payload, PLUGIN_ID):
                continue
            injected = copy.deepcopy(params)
            injected[param_name] = [payload]
            new_query = urlencode(injected, doseq=True)
            fuzz_url = urlunparse(parsed._replace(query=new_query))
            resp = _safe_get(fuzz_url, session, safety, payload_meta["id"])
            if resp and _has_error_sig(resp.text):
                findings.append(_make_finding(
                    url=fuzz_url,
                    original_url=url,
                    parameter=param_name,
                    payload=payload,
                    payload_id=payload_meta["id"],
                    method="GET",
                    response_excerpt=_excerpt(resp.text),
                ))
    return findings


def _test_form(form: dict, session: requests.Session, safety) -> list[dict]:
    findings = []
    action = form["action"]
    method = form.get("method", "GET").upper()
    fields = form.get("fields", [])

    for field_meta in fields:
        field_name = field_meta["name"]
        for payload_meta in _PAYLOADS:
            payload = payload_meta["value"]
            if safety and not safety.check_payload(payload, PLUGIN_ID):
                continue
            data = {f["name"]: f.get("value", "test") for f in fields}
            data[field_name] = payload
            resp = _safe_request(action, method, data, session, safety, payload_meta["id"])
            if resp and _has_error_sig(resp.text):
                findings.append(_make_finding(
                    url=action,
                    original_url=action,
                    parameter=field_name,
                    payload=payload,
                    payload_id=payload_meta["id"],
                    method=method,
                    response_excerpt=_excerpt(resp.text),
                ))
    return findings


def _has_error_sig(text: str) -> bool:
    lower = text.lower()
    return any(sig in lower for sig in _SIGS)


def _safe_get(url, session, safety, pid):
    try:
        if safety:
            safety.acquire()
            safety.log_request(url, PLUGIN_ID, pid)
        resp = session.get(url, timeout=10)
        return resp
    except Exception:
        return None
    finally:
        if safety:
            safety.release()


def _safe_request(url, method, data, session, safety, pid):
    try:
        if safety:
            safety.acquire()
            safety.log_request(url, PLUGIN_ID, pid)
        if method == "POST":
            resp = session.post(url, data=data, timeout=10)
        else:
            resp = session.get(url, params=data, timeout=10)
        return resp
    except Exception:
        return None
    finally:
        if safety:
            safety.release()


def _make_finding(url, original_url, parameter, payload, payload_id, method, response_excerpt):
    return {
        "plugin_id":        PLUGIN_ID,
        "title":            f"SQL Injection in parameter '{parameter}'",
        "severity":         "critical",
        "validation_level": 1,
        "url":              url,
        "original_url":     original_url,
        "parameter":        parameter,
        "method":           method,
        "evidence": {
            "payload":           payload,
            "payload_id":        payload_id,
            "response_excerpt":  response_excerpt,
        },
        "reproduction":     f"curl -G '{original_url}' --data-urlencode \"{parameter}={payload}\"",
        "impact":           "Authentication bypass; full database read/write/delete access possible.",
        "remediation": (
            "Use parameterized queries / prepared statements. Never concatenate user input "
            "into SQL strings. Reference: https://cheatsheetseries.owasp.org/cheatsheets/"
            "SQL_Injection_Prevention_Cheat_Sheet.html"
        ),
        "cwe":   "CWE-89",
        "owasp": "A03:2021",
    }


def _excerpt(text: str, max_len: int = 400) -> str:
    return text[:max_len].replace("\n", " ")


def _same_origin(base_url: str, target_url: str) -> bool:
    return urlparse(base_url).netloc == urlparse(target_url).netloc


def _dedup(findings: list[dict]) -> list[dict]:
    seen = set()
    out = []
    for f in findings:
        key = (f["url"], f["parameter"], f["evidence"]["payload_id"])
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out
