"""
SSRF Plugin (OOB Callback, Level 2)
====================================
Injects an OOB callback URL into parameters whose names suggest they
accept URLs (url=, redirect=, proxy=, etc.).

Validation is out-of-band: if the OOB server records a hit for the token
within the polling window, the finding is Level 2 (exploitability demonstrated).

No destructive payloads. The injected URL points only to the local OOB
sidecar — never to external internet resources.
"""
from __future__ import annotations

import copy
from urllib.parse import urlencode, parse_qs, urlparse, urlunparse

import requests
import yaml
from pathlib import Path

from dast.validator import make_oob_token, oob_callback_url, poll_oob

PLUGIN_ID = "SSRF-001"
_META = yaml.safe_load((Path(__file__).parent / "plugin.yaml").read_text())
_SUSPICIOUS = {p.lower() for p in _META["suspicious_param_names"]}


def run(url: str, session: requests.Session, safety=None, forms=None) -> list[dict]:
    findings = []
    findings += _test_url_params(url, session, safety)
    for form in (forms or []):
        if _same_origin(url, form.get("action", url)):
            findings += _test_form(form, session, safety)
    return findings


def _test_url_params(url: str, session: requests.Session, safety) -> list[dict]:
    parsed = urlparse(url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    findings = []
    for param_name in params:
        if param_name.lower() not in _SUSPICIOUS:
            continue
        token = make_oob_token()
        cb_url = oob_callback_url(token)
        injected = copy.deepcopy(params)
        injected[param_name] = [cb_url]
        fuzz_url = urlunparse(parsed._replace(query=urlencode(injected, doseq=True)))
        _safe_get(fuzz_url, session, safety, "ssrf-oob")
        if poll_oob(token, timeout=8.0):
            findings.append(_make_finding(
                url=fuzz_url, original_url=url,
                parameter=param_name, method="GET",
                token=token, cb_url=cb_url,
            ))
    return findings


def _test_form(form: dict, session: requests.Session, safety) -> list[dict]:
    findings = []
    action = form["action"]
    method = form.get("method", "GET").upper()
    fields = form.get("fields", [])
    for field_meta in fields:
        field_name = field_meta["name"]
        if field_name.lower() not in _SUSPICIOUS:
            continue
        token = make_oob_token()
        cb_url = oob_callback_url(token)
        data = {f["name"]: f.get("value", "test") for f in fields}
        data[field_name] = cb_url
        _safe_request(action, method, data, session, safety, "ssrf-oob-form")
        if poll_oob(token, timeout=8.0):
            findings.append(_make_finding(
                url=action, original_url=action,
                parameter=field_name, method=method,
                token=token, cb_url=cb_url,
            ))
    return findings


def _safe_get(url, session, safety, pid):
    try:
        if safety:
            safety.acquire()
            safety.log_request(url, PLUGIN_ID, pid)
        return session.get(url, timeout=10)
    except Exception:
        return None
    finally:
        if safety:
            safety.release()


def _safe_request(url, method, data, session, safety, pid):
    try:
        if safety:
            safety.acquire()
            safety.log_request(url, PLUGIN_ID, pid)
        if method == "POST":
            return session.post(url, data=data, timeout=10)
        return session.get(url, params=data, timeout=10)
    except Exception:
        return None
    finally:
        if safety:
            safety.release()


def _make_finding(url, original_url, parameter, method, token, cb_url):
    return {
        "plugin_id":        PLUGIN_ID,
        "title":            f"SSRF via parameter '{parameter}'",
        "severity":         "high",
        "validation_level": 2,
        "url":              url,
        "original_url":     original_url,
        "parameter":        parameter,
        "method":           method,
        "evidence": {
            "oob_token":    token,
            "oob_callback": cb_url,
            "proof":        f"OOB callback received for token {token}",
        },
        "reproduction": (
            f"curl -G '{original_url}' "
            f"--data-urlencode \"{parameter}=http://<attacker-controlled-host>/\"\n"
            f"# The server will make an outbound HTTP request to the attacker host."
        ),
        "impact": (
            "Attacker can make the server issue requests to internal network services, "
            "cloud metadata endpoints (169.254.169.254), or external resources. "
            "Can lead to credential theft, internal port scanning, and RCE."
        ),
        "remediation": (
            "Validate and allowlist permitted URL schemes and hosts. "
            "Block requests to private IP ranges (RFC1918, link-local). "
            "Reference: https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html"
        ),
        "cwe":   "CWE-918",
        "owasp": "A10:2021",
    }


def _same_origin(a: str, b: str) -> bool:
    return urlparse(a).netloc == urlparse(b).netloc
