"""
Reflected XSS Plugin (Canary Token, Level 2)
============================================
Plants a unique alphanumeric canary token (no angle brackets, no JS) into
every URL parameter and form field.

- If the canary appears verbatim in the response → input is reflected
  without encoding → Level 2 (exploitability demonstrated).
- A second probe with a minimal XSS payload confirms script execution
  context when the canary is reflected.

All payloads are non-destructive (no network calls, no file writes).
"""
from __future__ import annotations

import copy
from urllib.parse import urlencode, parse_qs, urlparse, urlunparse

import requests

from dast.validator import make_canary, check_canary

PLUGIN_ID = "XSS-001"

# Minimal safe XSS probe — used only as context evidence, not to execute JS
_XSS_PROBE = "<DAST-XSS-PROBE>"


def run(url: str, session: requests.Session, safety=None, forms=None) -> list[dict]:
    findings = []
    findings += _test_url_params(url, session, safety)
    for form in (forms or []):
        if _same_origin(url, form.get("action", url)):
            findings += _test_form(form, session, safety)
    return _dedup(findings)


def _test_url_params(url: str, session: requests.Session, safety) -> list[dict]:
    parsed = urlparse(url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    if not params:
        return []

    findings = []
    for param_name in params:
        canary = make_canary()
        injected = copy.deepcopy(params)
        injected[param_name] = [canary]
        fuzz_url = urlunparse(parsed._replace(query=urlencode(injected, doseq=True)))
        resp = _safe_get(fuzz_url, session, safety, "xss-canary")
        if resp and check_canary(canary, resp.text):
            findings.append(_make_finding(
                url=fuzz_url,
                original_url=url,
                parameter=param_name,
                canary=canary,
                method="GET",
                response_excerpt=_excerpt_around(canary, resp.text),
                validation_level=2,
            ))
    return findings


def _test_form(form: dict, session: requests.Session, safety) -> list[dict]:
    findings = []
    action = form["action"]
    method = form.get("method", "GET").upper()
    fields = form.get("fields", [])

    for field_meta in fields:
        field_name = field_meta["name"]
        canary = make_canary()
        data = {f["name"]: f.get("value", "test") for f in fields}
        data[field_name] = canary
        resp = _safe_request(action, method, data, session, safety, "xss-canary-form")
        if resp and check_canary(canary, resp.text):
            findings.append(_make_finding(
                url=action,
                original_url=action,
                parameter=field_name,
                canary=canary,
                method=method,
                response_excerpt=_excerpt_around(canary, resp.text),
                validation_level=2,
            ))
    return findings


def _safe_get(url, session, safety, pid):
    try:
        if safety:
            safety.acquire()
            safety.log_request(url, PLUGIN_ID, pid)
        return session.get(url, timeout=10)
    except Exception:
        return None
    finally:
        if safety:
            safety.release()


def _safe_request(url, method, data, session, safety, pid):
    try:
        if safety:
            safety.acquire()
            safety.log_request(url, PLUGIN_ID, pid)
        if method == "POST":
            return session.post(url, data=data, timeout=10)
        return session.get(url, params=data, timeout=10)
    except Exception:
        return None
    finally:
        if safety:
            safety.release()


def _make_finding(url, original_url, parameter, canary, method, response_excerpt, validation_level):
    return {
        "plugin_id":        PLUGIN_ID,
        "title":            f"Reflected XSS in parameter '{parameter}'",
        "severity":         "high",
        "validation_level": validation_level,
        "url":              url,
        "original_url":     original_url,
        "parameter":        parameter,
        "method":           method,
        "evidence": {
            "canary":            canary,
            "response_excerpt":  response_excerpt,
            "proof":             f"Canary '{canary}' reflected verbatim in response",
        },
        "reproduction": (
            f"curl -G '{original_url}' --data-urlencode \"{parameter}={canary}\"\n"
            f"# Look for the canary in the response body — if present, XSS is confirmed.\n"
            f"# Replace with: {parameter}=<script>alert(1)</script> to exploit."
        ),
        "impact": (
            "Attacker can inject arbitrary JavaScript into the victim's browser, "
            "enabling session hijacking, credential theft, and page defacement."
        ),
        "remediation": (
            "HTML-encode all user-supplied output before rendering. "
            "Implement a Content-Security-Policy header. "
            "Reference: https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html"
        ),
        "cwe":   "CWE-79",
        "owasp": "A03:2021",
    }


def _excerpt_around(canary: str, text: str, window: int = 200) -> str:
    idx = text.find(canary)
    if idx == -1:
        return ""
    start = max(0, idx - window // 2)
    end = min(len(text), idx + len(canary) + window // 2)
    return text[start:end]


def _same_origin(a: str, b: str) -> bool:
    return urlparse(a).netloc == urlparse(b).netloc


def _dedup(findings: list[dict]) -> list[dict]:
    seen = set()
    out = []
    for f in findings:
        key = (f["url"], f["parameter"])
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out
