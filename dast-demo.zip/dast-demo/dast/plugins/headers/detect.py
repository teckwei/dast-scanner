"""
Security Headers Plugin
=======================
Validation level 1 (Signature Matched): checks that the HTTP response
for each crawled page includes the recommended set of security headers.
No active attack payloads are sent.
"""
from __future__ import annotations

import requests


PLUGIN_ID = "HEADERS-001"

# (header_name, expected_pattern_or_None, remediation)
REQUIRED_HEADERS = [
    (
        "Content-Security-Policy",
        None,
        "Add a Content-Security-Policy header to restrict resource loading. "
        "Start with 'default-src \\'self\\''. Ref: https://owasp.org/www-project-secure-headers/",
    ),
    (
        "X-Frame-Options",
        None,
        "Add 'X-Frame-Options: DENY' or 'SAMEORIGIN' to prevent clickjacking.",
    ),
    (
        "X-Content-Type-Options",
        "nosniff",
        "Add 'X-Content-Type-Options: nosniff' to prevent MIME-type sniffing.",
    ),
    (
        "Strict-Transport-Security",
        None,
        "Add 'Strict-Transport-Security: max-age=31536000; includeSubDomains' "
        "to enforce HTTPS.",
    ),
    (
        "Referrer-Policy",
        None,
        "Add 'Referrer-Policy: no-referrer' or 'strict-origin-when-cross-origin'.",
    ),
    (
        "Permissions-Policy",
        None,
        "Add a Permissions-Policy header to restrict browser feature access.",
    ),
]

DANGEROUS_HEADERS = [
    (
        "X-Powered-By",
        "Remove the 'X-Powered-By' header to avoid technology fingerprinting.",
    ),
    (
        "Server",
        "Remove or obscure the 'Server' header version string.",
    ),
]


def run(url: str, session: requests.Session, safety=None, forms=None) -> list[dict]:
    """
    Returns a list of finding dicts (one per problematic header condition).
    """
    try:
        resp = session.get(url, timeout=10)
    except Exception:
        return []

    findings = []

    # Missing security headers
    for header, expected, remediation in REQUIRED_HEADERS:
        value = resp.headers.get(header)
        if value is None:
            findings.append(_make_finding(
                url=url,
                header=header,
                issue=f"Missing header: {header}",
                remediation=remediation,
                response_snippet=_header_snippet(resp),
                validation_level=1,
            ))
        elif expected and expected.lower() not in value.lower():
            findings.append(_make_finding(
                url=url,
                header=header,
                issue=f"Weak {header}: '{value}' (expected to contain '{expected}')",
                remediation=remediation,
                response_snippet=_header_snippet(resp),
                validation_level=1,
            ))

    # Dangerous information-disclosure headers
    for header, remediation in DANGEROUS_HEADERS:
        value = resp.headers.get(header)
        if value:
            findings.append(_make_finding(
                url=url,
                header=header,
                issue=f"Information-disclosure header present: {header}: {value}",
                remediation=remediation,
                response_snippet=_header_snippet(resp),
                validation_level=1,
            ))

    return findings


def _make_finding(url, header, issue, remediation, response_snippet, validation_level):
    return {
        "plugin_id":        PLUGIN_ID,
        "title":            issue,
        "severity":         "medium",
        "validation_level": validation_level,
        "url":              url,
        "parameter":        header,
        "evidence":         {"response_headers": response_snippet},
        "remediation":      remediation,
        "cwe":              "CWE-693",
        "owasp":            "A05:2021",
    }


def _header_snippet(resp: requests.Response) -> str:
    lines = []
    for k, v in resp.headers.items():
        lines.append(f"{k}: {v}")
    return "\n".join(lines[:30])
