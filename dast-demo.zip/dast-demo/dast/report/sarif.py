"""
SARIF 2.1.0 Emitter
====================
Converts a ScanResult into a valid SARIF 2.1.0 JSON document.

SARIF spec: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html

Key mappings:
  Finding.severity        → result.level  (error/warning/note/none)
  Finding.validation_level→ result.properties.validationLevel
  Finding.reproduction    → result.message.text
  Finding.cwe             → rule.relationships[].target.id
  Finding.remediation     → rule.help.text
"""
from __future__ import annotations

import json
from pathlib import Path


_SEVERITY_TO_LEVEL = {
    "critical": "error",
    "high":     "error",
    "medium":   "warning",
    "low":      "note",
    "info":     "none",
}


def emit(scan_result, output_path: str) -> str:
    """Write SARIF to output_path and return the path."""
    doc = build(scan_result)
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, indent=2))
    return str(path)


def build(scan_result) -> dict:
    findings = scan_result.findings
    rules = _build_rules(findings)
    results = [_finding_to_result(f) for f in findings]

    return {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name":            "DAST Scanner",
                        "version":         "1.0.0",
                        "informationUri":  "https://github.com/example/dast-demo",
                        "rules":           list(rules.values()),
                    }
                },
                "results": results,
                "properties": {
                    "scanId":       scan_result.scan_id,
                    "target":       scan_result.target,
                    "startedAt":    scan_result.started_at,
                    "finishedAt":   scan_result.finished_at,
                    "urlsCrawled":  scan_result.urls_crawled,
                    "fingerprint":  scan_result.fingerprint,
                },
            }
        ],
    }


def _build_rules(findings) -> dict:
    rules = {}
    for f in findings:
        rid = f.plugin_id
        if rid in rules:
            continue
        rules[rid] = {
            "id":               rid,
            "name":             f.title,
            "shortDescription": {"text": f.title},
            "fullDescription":  {"text": f.impact},
            "helpUri":          _cwe_uri(f.cwe),
            "help":             {"text": f.remediation, "markdown": f.remediation},
            "properties": {
                "tags":      [f.owasp, f.cwe],
                "severity":  f.severity,
                "precision": _validation_to_precision(f.validation_level),
            },
        }
    return rules


def _finding_to_result(f) -> dict:
    return {
        "ruleId":  f.plugin_id,
        "level":   _SEVERITY_TO_LEVEL.get(f.severity, "warning"),
        "message": {
            "text": (
                f"{f.title}\n\n"
                f"URL: {f.url}\n"
                f"Parameter: {f.parameter or 'N/A'}\n\n"
                f"Reproduction:\n{f.reproduction}\n\n"
                f"Remediation:\n{f.remediation}"
            )
        },
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {"uri": f.url},
                    "region":           {"startLine": 1},
                }
            }
        ],
        "properties": {
            "findingId":       f.id,
            "scanId":          f.scan_id,
            "severity":        f.severity,
            "validationLevel": f.validation_level,
            "parameter":       f.parameter,
            "method":          f.method,
            "impact":          f.impact,
            "ownerHint":       f.owner_hint,
            "firstSeen":       f.first_seen,
            "evidence":        f.evidence,
        },
        "relatedLocations": [
            {
                "id":      1,
                "message": {"text": "Evidence"},
                "physicalLocation": {
                    "artifactLocation": {"uri": f.url}
                },
            }
        ],
    }


def _cwe_uri(cwe: str) -> str:
    num = cwe.replace("CWE-", "")
    return f"https://cwe.mitre.org/data/definitions/{num}.html"


def _validation_to_precision(level: int) -> str:
    return {0: "low", 1: "medium", 2: "high"}.get(level, "low")
