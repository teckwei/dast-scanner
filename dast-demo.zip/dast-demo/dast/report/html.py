"""
HTML Report Generator
======================
Renders a human-readable HTML report from a ScanResult using an inline
Jinja2 template.  Three sections:

  1. Executive Summary  — risk score, finding counts by severity, top 3
  2. Developer View     — findings grouped by URL/endpoint with copy-paste
                          reproduction commands and fix guidance
  3. Full Findings Table — sortable, filterable, with validation level badges
"""
from __future__ import annotations

from pathlib import Path

from jinja2 import Environment, BaseLoader


_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DAST Report — {{ result.scan_id }}</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, "Segoe UI", system-ui, sans-serif; font-size: 14px;
         line-height: 1.6; background: #fff; color: #1f2328; }
  .wrap { max-width: 960px; margin: 0 auto; padding: 32px 24px; }
  h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
  h2 { font-size: 17px; font-weight: 600; margin: 28px 0 12px; border-bottom: 1px solid #e5e7eb; padding-bottom: 6px; }
  h3 { font-size: 14px; font-weight: 600; margin: 18px 0 6px; }
  p, li { margin-bottom: 6px; }
  a { color: #3b82d4; text-decoration: none; }
  a:hover { text-decoration: underline; }
  .muted { color: #57606a; font-size: 12px; }
  .surface { background: #f7f8fa; border: 1px solid #e5e7eb; border-radius: 6px; padding: 16px; margin-bottom: 12px; }
  /* Score strip */
  .score-strip { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 24px; }
  .score-card { flex: 1 1 120px; background: #f7f8fa; border: 1px solid #e5e7eb;
                border-radius: 8px; padding: 16px; text-align: center; }
  .score-card .num { font-size: 32px; font-weight: 700; }
  .score-card .label { font-size: 11px; color: #57606a; text-transform: uppercase; letter-spacing: .04em; }
  /* Severity badges */
  .badge { display: inline-block; padding: 1px 8px; border-radius: 10px;
           font-size: 11px; font-weight: 600; text-transform: uppercase; vertical-align: middle; }
  .critical { background: #fde8e8; color: #b91c1c; }
  .high     { background: #fff3e0; color: #c2410c; }
  .medium   { background: #fef9c3; color: #92400e; }
  .low      { background: #e0f2fe; color: #0369a1; }
  .info     { background: #f0fdf4; color: #166534; }
  /* Validation level badges */
  .vl0 { background: #f1f5f9; color: #475569; }
  .vl1 { background: #fef9c3; color: #92400e; }
  .vl2 { background: #dcfce7; color: #166534; }
  /* Table */
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { background: #f7f8fa; border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; font-weight: 600; }
  td { border: 1px solid #e5e7eb; padding: 8px 10px; vertical-align: top; }
  tr:hover td { background: #fafafa; }
  /* Code block */
  pre { background: #161b22; color: #e6edf3; border-radius: 6px; padding: 14px;
        font-size: 12px; overflow-x: auto; white-space: pre-wrap; word-break: break-all; margin: 8px 0; }
  /* Finding card */
  .finding-card { border-left: 4px solid #e5e7eb; margin-bottom: 20px; padding-left: 14px; }
  .finding-card.critical { border-color: #b91c1c; }
  .finding-card.high     { border-color: #c2410c; }
  .finding-card.medium   { border-color: #d97706; }
  .finding-card.low      { border-color: #0369a1; }
  .finding-title { font-weight: 600; margin-bottom: 4px; }
  details summary { cursor: pointer; color: #3b82d4; font-size: 12px; margin-top: 6px; }
  footer { margin-top: 48px; padding-top: 16px; border-top: 1px solid #e5e7eb;
           text-align: center; font-size: 12px; color: #57606a; }
  @media (max-width:600px) { .score-strip { flex-direction: column; } }
</style>
</head>
<body>
<div class="wrap">

  <h1>🔍 DAST Security Report</h1>
  <p class="muted">Scan ID: {{ result.scan_id }} &nbsp;·&nbsp; Target: <a href="{{ result.target }}">{{ result.target }}</a>
  &nbsp;·&nbsp; Started: {{ result.started_at[:19].replace("T", " ") }} UTC
  &nbsp;·&nbsp; URLs crawled: {{ result.urls_crawled }}</p>

  {% if result.fingerprint %}
  <p class="muted" style="margin-top:4px;">
    Stack detected:
    {% for k, v in result.fingerprint.items() if v and k != "raw_tags" and k != "js_libs" %}
      <strong>{{ k }}:</strong> {{ v }}&nbsp;
    {% endfor %}
    {% if result.fingerprint.js_libs %}
      <strong>JS:</strong> {{ result.fingerprint.js_libs | join(", ") }}
    {% endif %}
  </p>
  {% endif %}

  <!-- Executive Summary -->
  <h2>Executive Summary</h2>

  {% set counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0} %}
  {% for f in result.findings %}{% set _ = counts.update({f.severity: counts[f.severity] + 1}) %}{% endfor %}

  <div class="score-strip">
    <div class="score-card"><div class="num" style="color:#b91c1c">{{ counts.critical }}</div><div class="label">Critical</div></div>
    <div class="score-card"><div class="num" style="color:#c2410c">{{ counts.high }}</div><div class="label">High</div></div>
    <div class="score-card"><div class="num" style="color:#d97706">{{ counts.medium }}</div><div class="label">Medium</div></div>
    <div class="score-card"><div class="num" style="color:#0369a1">{{ counts.low }}</div><div class="label">Low</div></div>
    <div class="score-card"><div class="num">{{ result.findings | length }}</div><div class="label">Total</div></div>
  </div>

  {% if top3 %}
  <h3>Top Priorities</h3>
  <ol>
    {% for f in top3 %}
    <li><span class="badge {{ f.severity }}">{{ f.severity }}</span>
        <strong>{{ f.title }}</strong> — {{ f.url }}</li>
    {% endfor %}
  </ol>
  {% endif %}

  <!-- Developer View -->
  <h2>Findings by Endpoint</h2>

  {% for url, url_findings in findings_by_url.items() %}
  <div style="margin-bottom:24px;">
    <h3 style="word-break:break-all">{{ url }}</h3>
    {% for f in url_findings %}
    <div class="finding-card {{ f.severity }}">
      <div class="finding-title">
        <span class="badge {{ f.severity }}">{{ f.severity }}</span>
        <span class="badge vl{{ f.validation_level }}">
          Level {{ f.validation_level }}:
          {% if f.validation_level == 2 %}Exploited{% elif f.validation_level == 1 %}Signature{% else %}Unverified{% endif %}
        </span>
        &nbsp;{{ f.title }}
        <span class="muted">&nbsp;{{ f.cwe }} / {{ f.owasp }}</span>
      </div>
      <p style="margin-top:6px;color:#57606a;font-size:13px;">{{ f.impact }}</p>
      {% if f.reproduction %}
      <details>
        <summary>▶ Reproduction</summary>
        <pre>{{ f.reproduction }}</pre>
      </details>
      {% endif %}
      {% if f.evidence %}
      <details>
        <summary>▶ Evidence</summary>
        <pre>{{ f.evidence | tojson(indent=2) }}</pre>
      </details>
      {% endif %}
      <details>
        <summary>▶ Remediation</summary>
        <p style="padding:8px 0;">{{ f.remediation }}</p>
      </details>
    </div>
    {% endfor %}
  </div>
  {% endfor %}

  {% if not result.findings %}
  <p class="surface">✅ No findings detected in this scan.</p>
  {% endif %}

  <!-- Full Findings Table -->
  <h2>All Findings</h2>
  {% if result.findings %}
  <table>
    <thead>
      <tr>
        <th>ID</th><th>Severity</th><th>Validation</th><th>Title</th>
        <th>URL</th><th>Parameter</th><th>CWE</th>
      </tr>
    </thead>
    <tbody>
      {% for f in result.findings %}
      <tr>
        <td>{{ f.id }}</td>
        <td><span class="badge {{ f.severity }}">{{ f.severity }}</span></td>
        <td><span class="badge vl{{ f.validation_level }}">L{{ f.validation_level }}</span></td>
        <td>{{ f.title }}</td>
        <td style="word-break:break-all;font-size:12px;">{{ f.url }}</td>
        <td>{{ f.parameter or "—" }}</td>
        <td><a href="{{ f.cwe | cwe_url }}" target="_blank">{{ f.cwe }}</a></td>
      </tr>
      {% endfor %}
    </tbody>
  </table>
  {% else %}
  <p>No findings.</p>
  {% endif %}

</div>
<footer>Made with IBM Bob</footer>
</body>
</html>
"""


def _cwe_url(cwe: str) -> str:
    num = cwe.replace("CWE-", "")
    return f"https://cwe.mitre.org/data/definitions/{num}.html"


def _tojson(obj, indent=None):
    import json
    return json.dumps(obj, indent=indent)


def emit(scan_result, output_path: str) -> str:
    env = Environment(loader=BaseLoader())
    env.filters["cwe_url"] = _cwe_url
    env.filters["tojson"] = _tojson
    tmpl = env.from_string(_TEMPLATE)

    # Group findings by URL
    findings_by_url: dict = {}
    for f in scan_result.findings:
        findings_by_url.setdefault(f.url, []).append(f)

    # Top 3 by severity
    _order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    top3 = sorted(scan_result.findings, key=lambda f: _order.get(f.severity, 5))[:3]

    html = tmpl.render(
        result=scan_result,
        findings_by_url=findings_by_url,
        top3=top3,
    )
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html)
    return str(path)
