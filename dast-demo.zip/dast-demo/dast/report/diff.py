"""
Scan Diff Engine
================
Compares two SARIF 2.1.0 files and produces:

  - introduced  : findings in scan B not present in scan A  (new regressions)
  - resolved    : findings in scan A not present in scan B  (fixed)
  - unchanged   : findings present in both scans

A finding is identified by a stable key:
  (ruleId, physicalLocation.uri, properties.parameter)

Emits:
  - Terminal summary (coloured)
  - diff.sarif  — SARIF with custom properties.diffStatus
  - diff.html   — visual diff report
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    from colorama import Fore, Style, init as _colorama_init
    _colorama_init(autoreset=True)
    _RED    = Fore.RED
    _GREEN  = Fore.GREEN
    _YELLOW = Fore.YELLOW
    _RESET  = Style.RESET_ALL
    _BOLD   = Style.BRIGHT
except ImportError:
    _RED = _GREEN = _YELLOW = _RESET = _BOLD = ""


@dataclass
class DiffResult:
    introduced: list[dict] = field(default_factory=list)
    resolved:   list[dict] = field(default_factory=list)
    unchanged:  list[dict] = field(default_factory=list)


def _result_key(result: dict) -> tuple:
    locs = result.get("locations", [{}])
    uri = ""
    if locs:
        uri = locs[0].get("physicalLocation", {}).get("artifactLocation", {}).get("uri", "")
    param = result.get("properties", {}).get("parameter") or ""
    return (result.get("ruleId", ""), uri, param)


def _load_results(sarif_path: str) -> dict:
    """Returns {key: result_dict} from a SARIF file."""
    data = json.loads(Path(sarif_path).read_text())
    out = {}
    for run in data.get("runs", []):
        for result in run.get("results", []):
            key = _result_key(result)
            out[key] = result
    return out


def diff(sarif_a: str, sarif_b: str) -> DiffResult:
    a = _load_results(sarif_a)
    b = _load_results(sarif_b)

    introduced = [b[k] for k in b if k not in a]
    resolved   = [a[k] for k in a if k not in b]
    unchanged  = [b[k] for k in b if k in a]

    return DiffResult(introduced=introduced, resolved=resolved, unchanged=unchanged)


def print_diff(dr: DiffResult):
    print(f"\n{_BOLD}{'─'*60}{_RESET}")
    print(f"{_BOLD}  SCAN DIFF SUMMARY{_RESET}")
    print(f"{'─'*60}")
    print(f"  {_RED}▲ Introduced (new): {len(dr.introduced):>3}{_RESET}")
    print(f"  {_GREEN}▼ Resolved   (fixed): {len(dr.resolved):>3}{_RESET}")
    print(f"  {_YELLOW}● Unchanged:          {len(dr.unchanged):>3}{_RESET}")
    print(f"{'─'*60}\n")

    if dr.introduced:
        print(f"{_RED}{_BOLD}NEW FINDINGS:{_RESET}")
        for r in dr.introduced:
            props = r.get("properties", {})
            locs = r.get("locations", [{}])
            uri = locs[0].get("physicalLocation", {}).get("artifactLocation", {}).get("uri", "?") if locs else "?"
            sev = props.get("severity", "?").upper()
            print(f"  {_RED}[{sev}]{_RESET} {r.get('ruleId', '?')} — {r.get('message', {}).get('text', '')[:80]}")
            print(f"         {uri}\n")

    if dr.resolved:
        print(f"{_GREEN}{_BOLD}RESOLVED FINDINGS:{_RESET}")
        for r in dr.resolved:
            props = r.get("properties", {})
            sev = props.get("severity", "?").upper()
            print(f"  {_GREEN}[{sev}]{_RESET} {r.get('ruleId', '?')} — {r.get('message', {}).get('text', '')[:80]}\n")


def emit_diff_sarif(dr: DiffResult, sarif_b: str, output_path: str) -> str:
    """Write an annotated SARIF where each result has properties.diffStatus."""
    base = json.loads(Path(sarif_b).read_text())
    for run in base.get("runs", []):
        results = run.get("results", [])
        run["results"] = []
        for r in results:
            k = _result_key(r)
            if k in {_result_key(x) for x in dr.introduced}:
                r.setdefault("properties", {})["diffStatus"] = "introduced"
            else:
                r.setdefault("properties", {})["diffStatus"] = "unchanged"
            run["results"].append(r)
        for r in dr.resolved:
            r.setdefault("properties", {})["diffStatus"] = "resolved"
            run["results"].append(r)

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(base, indent=2))
    return str(path)


_DIFF_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>DAST Diff Report</title>
<style>
  body { font-family: -apple-system,"Segoe UI",system-ui,sans-serif; font-size:14px;
         line-height:1.6; background:#fff; color:#1f2328; }
  .wrap { max-width:900px; margin:0 auto; padding:32px 24px; }
  h1 { font-size:20px; font-weight:700; }
  h2 { font-size:15px; font-weight:600; margin:24px 0 10px; border-bottom:1px solid #e5e7eb; padding-bottom:4px; }
  .badge { display:inline-block; padding:1px 8px; border-radius:10px; font-size:11px; font-weight:600; }
  .introduced { background:#fde8e8; color:#b91c1c; }
  .resolved   { background:#dcfce7; color:#166534; }
  .unchanged  { background:#f1f5f9; color:#475569; }
  table { width:100%; border-collapse:collapse; font-size:13px; margin-bottom:20px; }
  th { background:#f7f8fa; border:1px solid #e5e7eb; padding:7px 10px; }
  td { border:1px solid #e5e7eb; padding:7px 10px; vertical-align:top; }
  footer { margin-top:40px; padding-top:12px; border-top:1px solid #e5e7eb;
           text-align:center; font-size:12px; color:#57606a; }
</style>
</head>
<body>
<div class="wrap">
<h1>DAST Scan Diff</h1>
<p style="color:#57606a">Scan A vs Scan B comparison</p>

<div style="display:flex;gap:20px;margin:16px 0">
  <div style="flex:1;background:#fde8e8;border:1px solid #fca5a5;border-radius:6px;padding:16px;text-align:center">
    <div style="font-size:28px;font-weight:700;color:#b91c1c">INTRODUCED_COUNT</div>
    <div style="font-size:11px;color:#57606a;text-transform:uppercase">New Findings</div>
  </div>
  <div style="flex:1;background:#dcfce7;border:1px solid #86efac;border-radius:6px;padding:16px;text-align:center">
    <div style="font-size:28px;font-weight:700;color:#166534">RESOLVED_COUNT</div>
    <div style="font-size:11px;color:#57606a;text-transform:uppercase">Resolved</div>
  </div>
  <div style="flex:1;background:#f1f5f9;border:1px solid #cbd5e1;border-radius:6px;padding:16px;text-align:center">
    <div style="font-size:28px;font-weight:700;color:#475569">UNCHANGED_COUNT</div>
    <div style="font-size:11px;color:#57606a;text-transform:uppercase">Unchanged</div>
  </div>
</div>

INTRODUCED_SECTION
RESOLVED_SECTION
</div>
<footer>Made with IBM Bob</footer>
</body></html>"""


def _rows_html(results: list[dict]) -> str:
    rows = ""
    for r in results:
        props = r.get("properties", {})
        locs = r.get("locations", [{}])
        uri = locs[0].get("physicalLocation", {}).get("artifactLocation", {}).get("uri", "?") if locs else "?"
        sev = props.get("severity", "info")
        vl  = props.get("validationLevel", 0)
        rows += (
            f"<tr><td>{r.get('ruleId','')}</td>"
            f"<td><span class='badge {sev}'>{sev}</span></td>"
            f"<td>L{vl}</td>"
            f"<td style='word-break:break-all;font-size:12px'>{uri}</td>"
            f"<td style='font-size:12px'>{props.get('parameter') or '—'}</td></tr>\n"
        )
    return rows


def _section_html(title: str, css_class: str, results: list[dict]) -> str:
    if not results:
        return ""
    rows = _rows_html(results)
    return (
        f"<h2><span class='badge {css_class}'>{title} ({len(results)})</span></h2>"
        f"<table><thead><tr><th>Rule</th><th>Severity</th><th>Level</th>"
        f"<th>URL</th><th>Parameter</th></tr></thead><tbody>{rows}</tbody></table>"
    )


def emit_diff_html(dr: DiffResult, output_path: str) -> str:
    html = _DIFF_HTML
    html = html.replace("INTRODUCED_COUNT", str(len(dr.introduced)))
    html = html.replace("RESOLVED_COUNT",   str(len(dr.resolved)))
    html = html.replace("UNCHANGED_COUNT",  str(len(dr.unchanged)))
    html = html.replace("INTRODUCED_SECTION", _section_html("Introduced", "introduced", dr.introduced))
    html = html.replace("RESOLVED_SECTION",   _section_html("Resolved",   "resolved",   dr.resolved))

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html)
    return str(path)
