#!/usr/bin/env bash
# scan2.sh — Second scan (simulated fix applied) + diff against scan-001
#
# What this demonstrates:
#   1. Run scan-002 with the /search* path excluded (simulating XSS fix deployed)
#   2. Diff scan-001.sarif vs scan-002.sarif
#   3. Show introduced / resolved / unchanged findings

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"

echo "================================================================"
echo "  DAST Demo — Scan 2 (post-fix) + Diff"
echo "================================================================"
echo ""

# Check scan-001 exists
if [ ! -f "$ROOT/reports/scan-001.sarif" ]; then
  echo "ERROR: reports/scan-001.sarif not found."
  echo "Run scripts/scan1.sh first."
  exit 1
fi

echo "Running scan-002 (search/* excluded to simulate XSS fix)..."
cd "$ROOT"
python -m dast.cli scan \
  --config scan2.yaml \
  --scan-id scan-002 \
  --out reports \
  --format sarif,html \
  --fail-on none

echo ""
echo "Scan 2 complete."
echo "  SARIF  : $ROOT/reports/scan-002.sarif"
echo "  HTML   : $ROOT/reports/scan-002.html"
echo ""

echo "================================================================"
echo "  Running diff: scan-001 vs scan-002"
echo "================================================================"
echo ""

python -m dast.cli diff \
  reports/scan-001.sarif \
  reports/scan-002.sarif \
  --out reports

echo ""
echo "Diff reports written:"
echo "  SARIF  : $ROOT/reports/diff.sarif"
echo "  HTML   : $ROOT/reports/diff.html"
echo ""
echo "Open the diff report:"
echo "  open reports/diff.html"
