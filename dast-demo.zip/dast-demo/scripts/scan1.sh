#!/usr/bin/env bash
# scan1.sh — Baseline scan against OWASP Juice Shop
# Runs scan-001, emits reports/scan-001.sarif + reports/scan-001.html

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"

echo "================================================================"
echo "  DAST Demo — Scan 1 (baseline)"
echo "================================================================"
echo ""
echo "Starting OOB server and Juice Shop (if not already running)..."
docker compose -f "$ROOT/docker-compose.yml" up -d juiceshop oob-server

echo ""
echo "Waiting for Juice Shop to be ready..."
until curl -sf http://localhost:3000 > /dev/null 2>&1; do
  echo "  ... waiting"
  sleep 3
done
echo "  Juice Shop is ready."

echo ""
echo "Running scan-001..."
cd "$ROOT"
python -m dast.cli scan \
  --config scan.yaml \
  --scan-id scan-001 \
  --out reports \
  --format sarif,html \
  --fail-on none       # don't fail the script on findings for demo purposes

echo ""
echo "Scan 1 complete."
echo "  SARIF  : $ROOT/reports/scan-001.sarif"
echo "  HTML   : $ROOT/reports/scan-001.html"
echo "  Audit  : $ROOT/reports/audit-scan-001.jsonl"
echo ""
echo "Open the HTML report:"
echo "  open reports/scan-001.html"
